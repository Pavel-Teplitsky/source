﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Groupdocs.Annotation.Dotnet.Controllers
{
    using Groupdocs.Web.Annotation;
    using Groupdocs.Api.Contract;
    using StructureMap;

    public class HomeController : Controller
    {
        private const string _filePath = "Quick_Start_Guide_To_Using_GroupDocs.pdf";

        public ActionResult Index(string un)
        {
            if (!String.IsNullOrEmpty(un))
            {
                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(un, true, 1439200);
                string encryptedTicket = FormsAuthentication.Encrypt(ticket);
                HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                cookie.Expires = ticket.Expiration;
                Response.Cookies.Add(cookie);

                // add user to the document collaborator list
                var svc = ObjectFactory.GetInstance<IAnnotationService>();
                svc.AddCollaborator(_filePath, un, null, null, null);
            }
            else
            {
                var cookie = new HttpCookie(FormsAuthentication.FormsCookieName) { Expires = DateTime.UtcNow.AddDays(-1) };
                Response.Cookies.Add(cookie);
                Session.Abandon();

                // add anonymous user to the document collaborator list
                var svc = ObjectFactory.GetInstance<IAnnotationService>();
                svc.AddCollaborator(_filePath, "groupdocs@groupdocs.com", "Anonym", "A.", null); // allow anonymous users to annotate on a document
            }

            return View();
        }
    }
}
