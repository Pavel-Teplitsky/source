﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace Groupdocs.Demo.Annotation.Webforms
{
    using Groupdocs.Web.Annotation;
    using StructureMap;

    public partial class _Default : System.Web.UI.Page
    {
        private const string _filePath = "Quick_Start_Guide_To_Using_GroupDocs.pdf";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var un = Request["un"];

                if (!String.IsNullOrEmpty(un))
                {
                    //System.Web.Security.Membership.ValidateUser(un, null);

                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(un, true, 1439200);
                    string encryptedTicket = FormsAuthentication.Encrypt(ticket);
                    HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    cookie.Expires = ticket.Expiration;
                    Response.Cookies.Add(cookie);
                    // add user to the document collaborator list
                    var svc = ObjectFactory.GetInstance<IAnnotationService>();
                    svc.AddCollaborator(_filePath, un, null, null, null); // allow anonymous users to annotate on a document
                }
                else
                {
                    var cookie = new HttpCookie(FormsAuthentication.FormsCookieName) { Expires = DateTime.UtcNow.AddDays(-1) };
                    Response.Cookies.Add(cookie);
                    Session.Abandon();

                    // add anonymous user to the document collaborator list
                    var svc = ObjectFactory.GetInstance<IAnnotationService>();
                    svc.AddCollaborator(_filePath, "groupdocs@groupdocs.com", "Anonym", "A.", null); // allow anonymous users to annotate on a document
                }
            }
        }
    }
}
